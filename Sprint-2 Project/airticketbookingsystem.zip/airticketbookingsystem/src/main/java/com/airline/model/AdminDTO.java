package com.airline.model;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;

import com.airline.entity.Admin;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AdminDTO extends UserDTO {
	private String AName;
	private String email;
	

}
