package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Passenger;
import com.airline.model.PassengerDTO;
import com.airline.repository.PassengerRepository;
import com.airline.util.Converter;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PassengerServiceTest {

	@Autowired
	private PassengerService passengerService;
	
	@Autowired
	private Converter converter;
	
	@MockBean
	private PassengerRepository passengerRepository;
	
	//this method will test the savePassenger method
	
	@Test
	@Order(1)
	public void testCreatePassenger()
	{
		Passenger passenger=Passenger.builder().name("pallab").email("pallab@gmail.com")
				.phno("9905678945").userName("pallab").password("pallab123").role("user").build();
		
		Mockito.when(passengerRepository.save(passenger)).thenReturn(passenger);
		assertThat(passengerService.createPassenger(passenger)).isEqualTo("Passenger saved Successfully!!");
		
				
	}
	@Test
	@Order(2)
	void testGetAllPassengers()
	{
		Passenger passenger=Passenger.builder().name("pallab").email("pallab@gmail.com")
				.phno("9905678945").userName("pallab").password("pallab123").role("user").build();
		
		Passenger passenger1=Passenger.builder().name("chandan").email("chandan@gmail.com")
				.phno("9905678745").userName("chandan").password("chandan123").role("user").build();
		
		List<Passenger> list=new ArrayList<>();
		list.add(passenger);
		list.add(passenger1);
		
		Mockito.when(passengerRepository.findAll()).thenReturn(list);
		
		List<PassengerDTO> dto=passengerService.getAllPassenger();
		
		List<Passenger> pass=new ArrayList<Passenger>();
		dto.forEach(passDto->
		{
			pass.add(converter.covertToPassengerEntity(passDto));
		}
				
		);
		assertThat(pass).isEqualTo(list);
	}
	
	@Test
	@Order(6)
	void testDeletePassenger()
	{
		Passenger passenger=Passenger.builder().name("pallab").email("pallab@gmail.com")
				.phno("9905678945").userName("pallab").password("pallab123").role("user").build();
		
		Optional<Passenger> opPass=Optional.of(passenger);
		Mockito.when(passengerRepository.findById(opPass.get().getId())).thenReturn(opPass);
		assertThat(passengerService.deletePassenger(opPass.get().getId())).
		isEqualTo("Record deleted successfully!!");
	}
	@Test
	@Order(3)
	void testGetPassenger()
	{
		Passenger passenger=Passenger.builder().name("pallab").email("pallab@gmail.com")
				.phno("9905678945").userName("pallab").password("pallab123").role("user").build();
		
		Optional<Passenger> opPass=Optional.of(passenger);
		Mockito.when(passengerRepository.findById(opPass.get().getId())).thenReturn(opPass);
		
		PassengerDTO pDto=converter.convertToPassengerDTO(opPass.get());
		assertThat(passengerService.getPassengerById(passenger.getId())).isNotEqualTo(pDto);
	}
	
	@Test
	@DisplayName("Negative test case")
	@Order(4)
	void testNegativeGetPassenger()
	{
		Passenger passenger=Passenger.builder().name("pallab").email("pallab@gmail.com")
				.phno("9905678945").userName("pallab").password("pallab123").role("user").build();
		
		Optional<Passenger> opPass=Optional.of(passenger);
		Mockito.when(passengerRepository.findById(opPass.get().getId())).thenReturn(opPass);
		
		PassengerDTO pDto=converter.convertToPassengerDTO(opPass.get());
		assertThat(passengerService.getPassengerById(passenger.getId())).isEqualTo(pDto);
	}
	@Test
	@Order(5)
	void testUpdatePassenger()
	{
		Passenger passenger=Passenger.builder().name("pallab").email("pallab@gmail.com")
				.phno("9905678945").userName("pallab").password("pallab123").role("user").build();
		
		Optional<Passenger> opPass=Optional.of(passenger);
		
		Mockito.when(passengerRepository.findById(passenger.getId())).thenReturn(opPass);
		
		Passenger p=opPass.get();
		p.setName("chandan");
		
		Mockito.when(passengerRepository.save(p)).thenReturn(p);
		PassengerDTO pDto=converter.convertToPassengerDTO(p);
		
		PassengerDTO dto=passengerService.updatePassenger(passenger.getId(), passenger);
		assertEquals(dto.getName(), p.getName());
				
	}
}
