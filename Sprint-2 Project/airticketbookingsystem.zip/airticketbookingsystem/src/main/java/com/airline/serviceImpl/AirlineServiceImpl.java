package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.AirlineDTO;
import com.airline.model.FlightDTO;
import com.airline.repository.AirlineRepository;
import com.airline.repository.FlightRepository;
import com.airline.service.AdminService;
import com.airline.service.AirlineService;
import com.airline.util.AirlineConverter;
import com.airline.util.FlightConverter;

import antlr.collections.List;
@Service
public class AirlineServiceImpl implements AirlineService {

	//logger statically created
		private static final Logger l=LoggerFactory.getLogger(AirlineService.class);
	
		@Autowired
		AirlineRepository airlineRepository;
		@Autowired
		AirlineConverter airlineConverter;
		@Override
		public AirlineDTO saveAirline(Airline airline) {
			
			Airline air=airlineRepository.save(airline);
			l.info("airline "+airline.toString() +" added at " + new java.util.Date());
			return airlineConverter.convertToAirlineDTO(air);
			
	}
		@Override
		public AirlineDTO updateAirline(int id, Airline airline) {
			//we need to check wheather Airline with given exist in DB or not
			Airline existAir=airlineRepository.findById(id).orElseThrow(()->
			new ResourceNotFoundException("Airline", "id", id));
			//we will get data from client and set in existing Airline
			existAir.setAirlineName(airline.getAirlineName());
			existAir.setFare(airline.getFare());
			
		airlineRepository.save(existAir);
		l.info("airline with airline id: "+ id +" is updated at " + new java.util.Date());
		return airlineConverter.convertToAirlineDTO(existAir);
			
		}
		@Override
		public AirlineDTO getAirlineById(int id) {
			Airline air=airlineRepository.findById(id).orElseThrow(()->
			new ResourceNotFoundException("Airline", "id", id));
			l.info("fetching airline by"+id+ " at "+new java.util.Date());
			return airlineConverter.convertToAirlineDTO(air);
			
		}
		@Override
		public AirlineDTO getAirlineByName(String airlineName) {
			Airline air=airlineRepository.getAirlineByName(airlineName);
			l.info("fetching passenger details by airline name: "+airlineName+" at "+new java.util.Date());
			return airlineConverter.convertToAirlineDTO(air);
			
		}
		
		@Override
		public String deleteAirlineById(int id) {
			String msg=null;
			Optional<Airline> opPass=airlineRepository.findById(id);
			if(opPass.isPresent())
			{
				airlineRepository.deleteById(id);
				msg="record deleted successfully";
				l.info("deleting airline details by id: "+id+ " at "+new java.util.Date());
			}
			else {
				throw new ResourceNotFoundException("Airline", "id", id);
			}
			return msg;
		}

}
