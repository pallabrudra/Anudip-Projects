package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Admin;
import com.airline.entity.Airline;
import com.airline.entity.Passenger;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.AdminDTO;
import com.airline.model.PassengerDTO;
import com.airline.repository.AdminRepository;
import com.airline.service.AdminService;
import com.airline.service.PassengerService;
import com.airline.util.Converter;
@Service
public class AdminServiceImpl implements AdminService{
	
	//logger statically created
	private static final Logger l=LoggerFactory.getLogger(AdminService.class);
	
	@Autowired
	private AdminRepository adminRepository;
	@Autowired
	private Converter converter;
	@Override
	public AdminDTO createAdmin(Admin admin) {
		admin.setUserName(admin.getUserName());
		admin.setPassword(admin.getPassword());
		admin.setRole(admin.getRole());
		
		adminRepository.save(admin);
		l.info("admin"+admin.toString() +" added at " + new java.util.Date());
		return converter.convertToAdminDTO(admin);
	}

	@Override
	public AdminDTO updateAdmin(int id, Admin admin) {

		//we need to check wheather Admin with given exist in DB or not
				Admin existingAdmin=adminRepository.findById(id).orElseThrow(()->
				new ResourceNotFoundException("Admin", "id", id));
				//we will get data from client and set in existing Admin
				existingAdmin.setAName(admin.getAName());
				existingAdmin.setEmail(admin.getEmail());
				existingAdmin.setUserName(admin.getUserName());
				existingAdmin.setPassword(admin.getPassword());
				existingAdmin.setRole(admin.getRole());
			adminRepository.save(existingAdmin);
			l.info("admin with id: "+ id +" is updated at " + new java.util.Date());
			return converter.convertToAdminDTO(existingAdmin);
	}

	@Override
	public AdminDTO getAdminById(int id) {

		Admin admin=adminRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Admin", "id", id));
		l.info(" fetching details of admin by id: "+id+ " at "+new java.util.Date());
		return converter.convertToAdminDTO(admin);
	}

	@Override
	public List<AdminDTO> getAllAdmin() {
		List<Admin> admins = adminRepository.findAll();
		
		List<AdminDTO> adminDTO = new ArrayList<>();
		for(Admin ad: admins)
		{
			adminDTO.add(converter.convertToAdminDTO(ad));
		}
		l.info("Getting all admin details at "+ new java.util.Date());
		return adminDTO;
	}

	@Override
	public String deleteAdminById(int id) {
		
		String msg=null;
		Optional<Admin> opPass=adminRepository.findById(id);
		if(opPass.isPresent())
		{
			adminRepository.deleteById(id);
			msg="record deleted successfully";
			l.info("deleting admin by"+id+ " at "+new java.util.Date());;
		}
		else {
			throw new ResourceNotFoundException("Admin", "id", id);
		}
		return msg;
			
		}

	}