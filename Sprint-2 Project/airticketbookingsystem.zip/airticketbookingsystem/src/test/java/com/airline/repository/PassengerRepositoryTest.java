package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.airline.entity.Passenger;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE )
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class PassengerRepositoryTest {
	
	@Autowired
	private PassengerRepository passengerRepository; 
	
	@Test
	@Order(1)
	@Rollback(value=false)
	void savePassengerTest()
	{
		Passenger passenger=Passenger.builder().name("pallab").email("pallab@gmail.com")
				.phno("9905678945").userName("pallab").password("pallab123").role("user").build();
		
		Passenger p=passengerRepository.save(passenger);
		assertThat(p.getName()).isEqualTo("pallab");
	}
	@Test
	@Order(3)
	@Rollback(value=false)
	void getAllPassenger()
	{
		List<Passenger> list=passengerRepository.findAll();
		assertThat(list.size()).isGreaterThan(0);
	}
	@Test
	@Order(2)
	@Rollback(value=false)
	void updatePassenger()
	{
		Passenger exPass=passengerRepository.findById(6).get();
		exPass.setName("pallab rudra");
		Passenger p=passengerRepository.save(exPass);
		assertThat(p.getName()).isEqualTo("pallab rudra");
	}
	
	@Test
	@Rollback(value=false)
	@Order(5)
	void deletePassenger()
	{
		passengerRepository.deleteById(6);
		assertThrows(NoSuchElementException.class, ()->passengerRepository.findById(7).get()) ;
		//assertNull(pass);
	}
	@Test
	@Order(4)
	@Rollback(value=false)
	void updatePassengerNegativeTest()
	{
		Passenger exPass=passengerRepository.findById(6).get();
		exPass.setName("sanjib");
		Passenger p=passengerRepository.save(exPass);
		assertThat(p.getName()).isEqualTo("pallab rudra");
	}

}
