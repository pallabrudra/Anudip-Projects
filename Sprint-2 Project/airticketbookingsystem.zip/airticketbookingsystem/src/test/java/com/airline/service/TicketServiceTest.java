package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.entity.TicketBooking;
import com.airline.repository.TicketBookingRepository;
import com.airline.util.TicketBookingConverter;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TicketServiceTest {

	@Autowired
	TicketBookingService ticketBookingService;
	
	@MockBean
	TicketBookingRepository ticketRepository;
	
	@Autowired
	TicketBookingConverter ticketConverter;
	
	@Test
	@Order(1)
	void bookFlightTest()
	{	
		
		TicketBooking ticket = TicketBooking.builder().no_of_passenger(2).date(LocalDate.now()).
				source("kolkata").destination("delhi").build();
		
		Mockito.when(ticketRepository.save(ticket)).thenReturn(ticket);
		//assertThat(ticketBookingService.bookFlight(flight.getFlightId(),passenger.getId() , ticket)).isEqualTo("Your ticket has been booked successfully!!");
		assertEquals(ticket.getNo_of_passenger(), 2);
	}
	
	@Test
	@Order(2)
	@DisplayName("Negative Test Case")
	void cancelBookingTest()
	{
		Flight flight= Flight.builder().availableSeats(20).totalSeats(100).
				date(LocalDate.parse("2022-11-10")).time("10:30").source("kolkata").
				destination("bangalore").travellerClass("business").build();
		TicketBooking ticket = TicketBooking.builder().no_of_passenger(2).date(LocalDate.now()).
				source("kolkata").destination("delhi").fId(flight).build();
		
		Optional<TicketBooking> opt= Optional.of(ticket);
		Mockito.when(ticketRepository.findById(opt.get().getTicketId())).thenReturn(opt);
		
		assertThat(ticketBookingService.cancelBooking(opt.get().getTicketId())).isNotEqualTo("Your booking is cancelled!!");
	}
}
