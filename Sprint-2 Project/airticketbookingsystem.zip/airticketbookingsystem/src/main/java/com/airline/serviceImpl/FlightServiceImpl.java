package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.entity.Passenger;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.AirlineDTO;
import com.airline.model.FlightDTO;
import com.airline.model.PassengerDTO;
import com.airline.repository.AirlineRepository;
import com.airline.repository.FlightRepository;
import com.airline.service.AirlineService;
import com.airline.service.FlightService;
import com.airline.util.FlightConverter;
@Service
public class FlightServiceImpl implements FlightService{
	
	//logger statically created
	private static final Logger l=LoggerFactory.getLogger(FlightService.class);
	
	@Autowired
	FlightRepository flightRepository;
	@Autowired
	AirlineRepository airlineRepository;
	@Autowired
	FlightConverter flightConverter;
	@Override
	public FlightDTO saveFlight(Flight flight) {
		
		Flight fl=flightRepository.save(flight);
		l.info("Flight "+flight.toString() +" saved at " + new java.util.Date());
		return flightConverter.convertToFlightDTO(fl);
		
	}
	@Override
	public FlightDTO assignFlightToAirline(int flightId, int airlineId) {
		Flight flight=flightRepository.findById(flightId).get();
		Airline airline=airlineRepository.findById(airlineId).get();
		flight.setAirline(airline);
		Flight f=flightRepository.save(flight);
		l.info(" Assigned Flight by "+flightId +" to airline " +airlineId+" at " + new java.util.Date());
		return flightConverter.convertToFlightDTO(f);
		
	}
	@Override
	public List<FlightDTO> searchFlight(String source, String destination) {
		List<Flight> flights=(List<Flight>) flightRepository.FindBySourceAndDestination(source,destination);
		List<FlightDTO> fDto=new ArrayList<>();
		for(Flight f: flights)
		{
			fDto.add(flightConverter.convertToFlightDTO(f));
		}
		l.info("Searching flight by source:"+source+ " and destination "+destination+ " at "+new java.util.Date());
		return fDto;
	}
	@Override
	public FlightDTO updateFlight(int id, Flight flight) {
		//we need to check wheather Flight with given exist in DB or not
		Flight existFlight=flightRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Flight", "id", id));
		//we will get data from client and set in existing Flight
		existFlight.setAvailableSeats(flight.getAvailableSeats());
		existFlight.setDate(flight.getDate());
		existFlight.setTime(flight.getTime());
		existFlight.setTotalSeats(flight.getTotalSeats());
		existFlight.setTravellerClass(flight.getTravellerClass());
		existFlight.setSource(flight.getSource());
		existFlight.setDestination(flight.getDestination());
		flightRepository.save(existFlight);
		l.info("flight with flight id: "+ id +" is updated at " + new java.util.Date());
		return flightConverter.convertToFlightDTO(existFlight);
	}
	@Override
	public FlightDTO getFlightById(int id) {
		Flight fl=flightRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Flight", "id", id));
		l.info("fetching flight by"+id+ " at "+new java.util.Date());
		return flightConverter.convertToFlightDTO(fl);
	}
	@Override
	public String deleteFlightById(int id) {
		String msg=null;
		Optional<Flight> opPass=flightRepository.findById(id);
		if(opPass.isPresent())
		{
			flightRepository.deleteById(id);
			msg="Flight record deleted successfully!!";
			l.info("deleting flight details by id: "+id+ " at "+new java.util.Date());
		}
		else {
			throw new ResourceNotFoundException("Flight", "id", id);
		}
		return msg;
	}

	

}
